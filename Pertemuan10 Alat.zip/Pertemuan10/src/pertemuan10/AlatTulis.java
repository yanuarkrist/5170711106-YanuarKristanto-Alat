package pertemuan10;

public class AlatTulis extends Alat{

    String fungsiAlat, dimensiP,  dimensiL;

   public String fungsi() {
        System.out.print("masukkan fungsi alat : ");
        fungsiAlat = input.next();
        return fungsiAlat;
    }

   public String dimensi() {
        System.out.print("masukkan dimensi alat Panjang dan Lebar : ");
        dimensiP = input.next();
        dimensiL = input.next();
        return dimensiP + dimensiL; 
    }
}
