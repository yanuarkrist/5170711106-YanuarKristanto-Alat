package pertemuan10;

import java.util.Scanner;

public class Alat {

    Scanner input = new Scanner(System.in);
    String nama, harga, merk;

    public String NamaAlat() {
        System.out.print("Masukkan Nama Alat : ");
        nama = input.next();
        return nama;
    }

    public String HargaAlat() {
        System.out.print("Masukkan Harga Alat : ");
        harga = input.next();
        return harga;
    }

    public String MerkAlat() {
        System.out.print("Masukkan Merk Alat : ");
        merk = input.next();
        return merk;
    }

}
