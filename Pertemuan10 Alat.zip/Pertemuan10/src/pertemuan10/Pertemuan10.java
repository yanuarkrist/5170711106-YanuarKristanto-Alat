package pertemuan10;

import java.util.Scanner;

public class Pertemuan10 {

    static int pilih, jumlah;
    static String nm, hr,mrk, wjd, wrn, fng, p,l, jns, mnf;
    static Pertemuan10 output = new Pertemuan10();
    static Alat alt = new Alat();
    static AlatMandi AM = new AlatMandi();
    static AlatTulis AT = new AlatTulis();
    static AlatKesehatan AK = new AlatKesehatan();

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("1. Alat mandi : ");
        System.out.println("2. Alat Tulis : ");
        System.out.println("3. Alat Kesehatan : ");
        System.out.print("Pilih Jenis Alat  : ");
        pilih = input.nextInt();
        System.out.print("Masukkan jumlah alat : ");
        jumlah = input.nextInt();
        for (int i = 0; i < jumlah; i++) {
            switch (pilih) { 
                case 1:
                    nm = alt.NamaAlat();
                    hr = alt.HargaAlat();
                    mrk = alt.MerkAlat();
                    wjd = AM.wujud();
                    wrn = AM.warna();
                    System.out.println("Nama Alat : " + nm);
                    System.out.println("Harga Alat : " + hr);
                    System.out.println("merk Alat : " + mrk);
                    System.out.println("wujud Alat : " + wjd);
                    System.out.println("warna Alat  : " + wrn);
                    System.out.println("====================================");
                    break;
                case 2:
                    nm = alt.NamaAlat();
                    hr = alt.HargaAlat();
                    mrk = alt.MerkAlat();
                    fng = AT.fungsi();
                    p = AT.dimensi();
                    System.out.println("Nama alat : " + nm);
                    System.out.println("Harga alat : " + hr);
                    System.out.println("merk Alat : " + mrk);
                    System.out.println("fungsi alat : " + fng);
                    System.out.println("dimensi alat Panjang : " + AT.dimensiP + " lebar : "+ AT.dimensiL);
                    System.out.println("====================================");
                    break;
                case 3:
                    nm = alt.NamaAlat();
                    hr = alt.HargaAlat();
                    mrk = alt.MerkAlat();
                    jns = AK.jenis();
                    mnf = AK.manfaat();
                    System.out.println("Nama alat : " + nm);
                    System.out.println("Harga alat : " + hr);
                    System.out.println("merk Alat : " + mrk);
                    System.out.println("jenis alat : " + jns);
                    System.out.println("manfaat alat  : " + mnf);
                    System.out.println("====================================");
                    break;
            }
        }

    }

}
