package pertemuan10;

public class AlatMandi extends Alat {

    String wujudAlat,warnaAlat;

    public String wujud() {
        System.out.print("masukkan wujud alat : ");
        wujudAlat = input.next();
        return wujudAlat;
    }

    public String warna() {
        System.out.print("masukkan warna alat : ");
        warnaAlat = input.next();
        return warnaAlat;
    }
}
