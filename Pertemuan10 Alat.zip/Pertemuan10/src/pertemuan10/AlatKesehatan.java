package pertemuan10;

public class AlatKesehatan extends Alat {

    String jenisAlat, manfaatAlat;

    public String jenis() {
        System.out.print("masukkan jenis alat : ");
        jenisAlat = input.next();
        return jenisAlat;
    }

    public String manfaat() {
        System.out.print("masukkan manfaat alat : ");
        manfaatAlat = input.next();
        return manfaatAlat;
    }
}
